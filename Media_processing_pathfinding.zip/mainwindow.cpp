#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <iostream>
#include <QDesktopWidget>
using namespace std;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    scene = new QGraphicsScene(this);

    ui->graphicsView->setScene(scene);

    world = new World();
    vector<std::unique_ptr<Tile>> tiles = world->createWorld(":/worldmap4.png");

    for(auto & tile: tiles){
        //        cout << tile->getValue() << endl;
        int val = (int) (tile->getValue()*255);
        QBrush brush(qGray(qRed(val),qGreen(val),qBlue(val)));
        QPen pen(Qt::black);
        pen.setWidth(0);

        if(tile->getValue() != 1.0f){
            scene->addRect(tile->getXPos()*displaySize, tile->getYPos()*displaySize, displaySize, displaySize,pen,brush);
        }

    }


}

MainWindow::~MainWindow()
{
    delete ui;
}
